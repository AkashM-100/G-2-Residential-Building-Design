STAAD.Pro G+2 Building Project
------------------------------
This ZIP archive includes all essential files for a G+2 RCC residential building modeled and analyzed using STAAD.Pro.

Included Files:
1. building_plan.dwg - Sample AutoCAD drawing of the building plan (placeholder).
2. Gplus2_structure.std - STAAD.Pro structure model (placeholder).
3. Gplus2_report.pdf - Design report with structural details and IS codes.
4. load_calculations.xlsx - Dead, live, wind, and seismic load calculations.
5. beam_column_schedule.pdf - Beam and column reinforcement details.

Instructions:
- Open the .std file using STAAD.Pro.
- Review load cases, member specifications, and run analysis.
- Refer to the PDF and Excel for supporting calculations and details.
